<?php

namespace App\Models;

use CodeIgniter\Model;

class ProdusenModel extends Model
{
    protected $table = 'produsen';
    protected $primaryKey = 'idprodusen';
    protected $allowedFields = ['nama', 'jenis', 'alamat', 'telepon', 'email', 'is_active'];
    protected $useTimestamps = false;

    public function getProdusen($search = '', $perPage = 10)
    {
        $builder = $this->where('is_active', 1);
        
        if ($search) {
            $builder->groupStart()
                   ->like('nama', $search)
                   ->orLike('jenis', $search)
                   ->orLike('telepon', $search)
                   ->groupEnd();
        }
        
        return [
            'produsen' => $builder->paginate($perPage),
            'pager' => $builder->pager
        ];
    }

    public function getTotalProdusen()
    {
        return $this->where('is_active', 1)->countAll();
    }

    // Soft delete method
    public function softDelete($id)
    {
        return $this->update($id, ['is_active' => 0]);
    }
}