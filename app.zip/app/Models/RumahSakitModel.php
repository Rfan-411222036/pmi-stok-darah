<?php

namespace App\Models;

use CodeIgniter\Model;

class RumahSakitModel extends Model
{
    protected $table = 'rumah_sakit';
    protected $primaryKey = 'idrs';
    protected $allowedFields = ['nama_rs', 'alamat', 'telepon', 'email', 'jenis_rs', 'is_active'];
    protected $useTimestamps = false;

    public function getRumahSakit($search = '', $perPage = 10)
    {
        $builder = $this->where('is_active', 1);
        
        if ($search) {
            $builder->groupStart()
                   ->like('nama_rs', $search)
                   ->orLike('jenis_rs', $search)
                   ->orLike('telepon', $search)
                   ->groupEnd();
        }
        
        return [
            'rumah_sakit' => $builder->paginate($perPage),
            'pager' => $builder->pager
        ];
    }

    public function getTotalRumahSakit()
    {
        return $this->where('is_active', 1)->countAll();
    }

    // Soft delete method
    public function softDelete($id)
    {
        return $this->update($id, ['is_active' => 0]);
    }
}