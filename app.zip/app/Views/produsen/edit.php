<?= $this->include('templates/header') ?>
<?= $this->include('templates/navbar') ?>
<?= $this->include('templates/sidebar') ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $page_title ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('/dashboard') ?>">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="<?= base_url('/produsen') ?>">Produsen</a></li>
                        <li class="breadcrumb-item active">Edit</li>
                    </ol>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <form action="<?= base_url('/produsen/update/' . $produsen['idprodusen']) ?>" method="post">
                        <?= csrf_field() ?>
                        
                        <?php if (session()->getFlashdata('errors')): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach (session()->getFlashdata('errors') as $error): ?>
                                        <li><?= $error ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama">Nama Produsen *</label>
                                    <input type="text" class="form-control" id="nama" name="nama" 
                                           value="<?= old('nama', $produsen['nama']) ?>" 
                                           placeholder="Masukkan nama produsen" required>
                                </div>

                                <div class="form-group">
                                    <label for="jenis">Jenis Produsen *</label>
                                    <select class="form-control" id="jenis" name="jenis" required>
                                        <option value="">Pilih Jenis</option>
                                        <option value="perorangan" <?= old('jenis', $produsen['jenis']) == 'perorangan' ? 'selected' : '' ?>>Perorangan</option>
                                        <option value="perusahaan" <?= old('jenis', $produsen['jenis']) == 'perusahaan' ? 'selected' : '' ?>>Perusahaan</option>
                                        <option value="instansi" <?= old('jenis', $produsen['jenis']) == 'instansi' ? 'selected' : '' ?>>Instansi</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="telepon">Telepon *</label>
                                    <input type="text" class="form-control" id="telepon" name="telepon" 
                                           value="<?= old('telepon', $produsen['telepon']) ?>" 
                                           placeholder="Masukkan nomor telepon" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" 
                                           value="<?= old('email', $produsen['email']) ?>" 
                                           placeholder="Masukkan email">
                                </div>

                                <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <textarea class="form-control" id="alamat" name="alamat" 
                                              placeholder="Masukkan alamat lengkap" rows="4"><?= old('alamat', $produsen['alamat']) ?></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Update
                            </button>
                            <a href="<?= base_url('/produsen') ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Kembali
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>

<?= $this->include('templates/footer') ?>